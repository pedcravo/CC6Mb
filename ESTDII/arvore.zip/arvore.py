from collections import deque  # Importa deque, usado como fila para percursos na árvore

# Classe para representar um nó da árvore
class Node:
    def __init__(self, data):
        self.data = data
        self.left = None   # filho esquerdo
        self.right = None  # filho direito

# Classe da Árvore Binária
class BinaryTree:
    def __init__(self):
        self.root = None   # raiz da árvore começa vazia

    def insert_level_order(self, data):
        new_node = Node(data)

        # Se a árvore está vazia, o novo nó vira raiz
        if self.root is None:
            self.root = new_node
            return
        
        # instancia um deque, iniciando com a raiz
        q = deque([self.root])
        
        while q:
            current = q.popleft()
            print("current: ", current.data)
            # Verifica o filho esquerdo
            if current.left is None:
                current.left = new_node
                return
            else:
                q.append(current.left)

            # Verifica o filho direito
            if current.right is None:
                current.right = new_node
                return
            else:
                q.append(current.right)
        
 
    def inorder(self, node):
        # Travessia em ordem (esquerda → raiz → direita)
        if node is None:
            return
        self.inorder(node.left)
        print(node.data)
        self.inorder(node.right)
    
    def preorder(self, node):
        # Travessia pré-ordem (raiz → esquerda → direita)
        if node is None:
            return
        print(node.data)
        self.preorder(node.left)
        self.preorder(node.right)

    def postorder(self, node):
        # Travessia pós-ordem (esquerda → direita → raiz)
        if node is None:
            return
        self.postorder(node.left)
        self.postorder(node.right)
        print(node.data)
    
    def level_order(self):
        # Travessia por níveis (BFS)
        if self.root is None:
            return []
        
        result = []
        q = deque([self.root])

        while q:
            qLen = len(q)   # quantidade de nós no nível atual
            level = []      # lista para armazenar esse nível
            for _ in range(qLen):
                node = q.popleft()
                level.append(node.data)  # adiciona valor no nível
                if node.left:
                    q.append(node.left)
                if node.right:
                    q.append(node.right)
            result.append(level)  # salva o nível completo
        return result
    

    def is_perfect(self):
        # Árvore perfeita: todos os níveis preenchidos e todas folhas no mesmo nível
        def depth(node):
            d = 0
            while node:
                d += 1
                node = node.left
            return d

        def is_perfect_rec(node, d, level=1):
            if node is None:
                return True
            if node.left is None and node.right is None:
                return d == level
            if node.left is None or node.right is None:
                return False
            return is_perfect_rec(node.left, d, level + 1) and is_perfect_rec(node.right, d, level + 1)

        d = depth(self.root)
        return is_perfect_rec(self.root, d)

    def is_complete(self):
        # Árvore completa: todos os níveis cheios, exceto possivelmente o último (preenchido da esquerda pra direita)
        if self.root is None:
            return True
        q = deque([self.root])
        end = False  # flag para marcar se encontramos "buraco"
        while q:
            node = q.popleft()
            if node.left:
                if end:  # se já vimos buraco antes, não é completa
                    return False
                q.append(node.left)
            else:
                end = True
            if node.right:
                if end:
                    return False
                q.append(node.right)
            else:
                end = True
        return True

    def is_regular(self):
        # Árvore regular: todos os nós têm o mesmo grau (número de filhos)
        def check(node):
            if node is None:
                return True, None
            left_check, left_deg = check(node.left)
            right_check, right_deg = check(node.right)
            deg = int(node.left is not None) + int(node.right is not None)
            if left_deg is None and right_deg is None:
                return True, deg
            if left_deg is not None and right_deg is not None and left_deg == right_deg == deg:
                return left_check and right_check, deg
            return False, deg
        result, _ = check(self.root)
        return result

    def is_balanced(self):
        # Árvore balanceada: diferença de altura entre subárvores ≤ 1
        def height(node):
            if node is None:
                return 0
            return 1 + max(height(node.left), height(node.right))

        def check(node):
            if node is None:
                return True
            lh = height(node.left)
            rh = height(node.right)
            if abs(lh - rh) > 1:
                return False
            return check(node.left) and check(node.right)
        return check(self.root)

    def is_unbalanced(self):
        # Árvore desbalanceada = não balanceada
        return not self.is_balanced()


# Menu interativo
bt = BinaryTree()

while True:
    print("\n===== Árvore Binária Interativa =====")
    print("1. Inserir valor")
    print("2. Travessia In-Order")
    print("3. Travessia Pre-Order")
    print("4. Travessia Post-Order")
    print("5. Travessia Level-Order (por nível)")
    print("6. Verificar se a árvore é perfeita")
    print("7. Verificar se a árvore é completa")
    print("8. Verificar se a árvore é regular")
    print("9. Verificar se a árvore é balanceada")
    print("10. Verificar se a árvore é desbalanceada")
    print("11. Sair")
    
    opcao = input("Escolha uma opção: ")

    if opcao == '1':
        # Inserir valor inteiro na árvore
        valor = input("Digite um valor para inserir: ")
        if valor.isdigit() or (valor[0] == '-' and valor[1:].isdigit()):
            bt.insert_level_order(int(valor))
            print(f"Valor {valor} inserido na árvore.")
        else:
            print("Valor inválido! Digite um número inteiro.")
    elif opcao == '2':
        print("In-Order:")
        bt.inorder(bt.root)
        print()
    elif opcao == '3':
        print("Pre-Order:")
        bt.preorder(bt.root)
        print()
    elif opcao == '4':
        print("Post-Order:")
        bt.postorder(bt.root)
        print()
    elif opcao == '5':
        print("Level-Order (por nível):")
        levels = bt.level_order()
        for i, level in enumerate(levels):
            print(f"Nível {i}: {level}")
    elif opcao == '6':
        print("A árvore é perfeita?" , "Sim" if bt.is_perfect() else "Não")
    elif opcao == '7':
        print("A árvore é completa?" , "Sim" if bt.is_complete() else "Não")
    elif opcao == '8':
        print("A árvore é regular?" , "Sim" if bt.is_regular() else "Não")
    elif opcao == '9':
        print("A árvore é balanceada?" , "Sim" if bt.is_balanced() else "Não")
    elif opcao == '10':
        print("A árvore é desbalanceada?" , "Sim" if bt.is_unbalanced() else "Não")
    elif opcao == '11':
        print("Saindo...")
        break
    else:
        print("Opção inválida! Tente novamente.")
# Fim do código