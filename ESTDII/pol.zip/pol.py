class TreeNode:
    def __init__(self, data=None):
        self.data = data
        self.right = None
        self.left = None

class Stack:
    def __init__(self):
        self.elements = []
    
    def push(self, item):
        print(f"PUSH na pilha: {item.data}")
        self.elements.append(item)

    def pop(self):
        popped = self.elements.pop()
        print(f"POP da pilha: {popped.data}")
        return popped

# Expressao em notacao pos-fixada (Polonesa reversa)
expr = "4 5 + 5 3 - *".split()
stack = Stack()

# Construcao da arvore de expressao
print("== Inicio da construcao da arvore ==")
for term in expr:
    if term in "+-*/":
        # No de operador: cria no, conecta operandos
        print(f"Encontrado operador: {term}")
        node = TreeNode(term)
        node.right = stack.pop()
        node.left = stack.pop()
    else:
        # Nó de operando (número)
        print(f"Encontrado operando: {term}")
        node = TreeNode(int(term))
    stack.push(node)
print("== Construcao da arvore concluida ==\n")

# Função para exibir a árvore (visualização textual)
def print_tree(node, prefix="", is_left=True):
    if node is not None:
        print_tree(node.right, prefix + ("│   " if is_left else "    "), False)
        print(prefix + ("└── " if is_left else "┌── ") + str(node.data))
        print_tree(node.left, prefix + ("    " if is_left else "│   "), True)

# Função de avaliação da árvore de expressão
def calc(node):
    if node.data == "+":
        return calc(node.left) + calc(node.right)
    elif node.data == "-":
        return calc(node.left) - calc(node.right)
    elif node.data == "*":
        return calc(node.left) * calc(node.right)
    elif node.data == "/":
        return calc(node.left) / calc(node.right)
    else:
        return node.data

# Recupera a raiz da árvore da pilha
root = stack.pop()

# Exibe a raiz da árvore
print(f"Raiz da arvore: {root.data}\n")

# Visualização textual da árvore
print("== Visualizacao da Arvore de Expressao ==\n")
print_tree(root)

# Avalia a expressão
result = calc(root)
print("\n== Resultado da Expressao ==")
print(f"Resultado: {result}")